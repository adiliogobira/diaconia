<?php

namespace App\DataFixtures;

use App\Entity\Campaign;
use App\Entity\Church;
use App\Entity\Deacon;
use App\Entity\FinancialCategory;
use App\Entity\Member;
use App\Entity\Ministry;
use App\Entity\Schedule;
use App\Entity\ScheduleAssignment;
use App\Entity\Transaction;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

/**
 * Dados de demonstração: uma igreja (tenant) com usuários de cada perfil,
 * membros, diáconos, escalas e lançamentos financeiros.
 *
 * Rode: php bin/console doctrine:fixtures:load
 */
class AppFixtures extends Fixture
{
    public function __construct(private readonly UserPasswordHasherInterface $hasher)
    {
    }

    public function load(ObjectManager $em): void
    {
        // ---- Tenant ----
        $church = (new Church())
            ->setName('Igreja Betel — Sede')
            ->setSlug('betel-sede')
            ->setEmail('contato@betel.org')
            ->setPhone('(31) 90000-0000');
        $em->persist($church);

        // ---- Usuários (um por perfil) ----
        $perfis = [
            ['admin@betel.org', 'Administrador Geral', ['ROLE_ADMIN']],
            ['pastor@betel.org', 'Pr. João Silva', ['ROLE_PASTOR']],
            ['secretaria@betel.org', 'Ana Secretária', ['ROLE_SECRETARIO']],
            ['tesouraria@betel.org', 'Carlos Tesoureiro', ['ROLE_TESOUREIRO']],
            ['diacono@betel.org', 'Diác. Pedro', ['ROLE_DIACONO']],
        ];
        foreach ($perfis as [$mail, $nome, $roles]) {
            $u = (new User())->setEmail($mail)->setFullName($nome)->setRoles($roles)->setChurch($church);
            $u->setPassword($this->hasher->hashPassword($u, 'senha123'));
            $em->persist($u);
        }

        // ---- Ministérios ----
        $minLouvor = (new Ministry())->setName('Louvor')->setChurch($church);
        $minDiaconia = (new Ministry())->setName('Diaconia')->setChurch($church);
        $em->persist($minLouvor);
        $em->persist($minDiaconia);

        // ---- Categorias financeiras ----
        foreach ([['Dízimos','entrada'],['Ofertas','entrada'],['Energia','saida'],['Manutenção','saida']] as [$n,$d]) {
            $em->persist((new FinancialCategory())->setName($n)->setDirection($d)->setChurch($church));
        }

        // ---- Campanha ----
        $em->persist((new Campaign())->setName('Construção do Templo')->setGoalAmount('150000.00')->setChurch($church));

        // ---- Membros + diáconos ----
        $nomes = ['Pedro Alves','Marcos Souza','Lucas Dias','Tiago Nunes','Mateus Rocha','Rute Lima','Ester Gomes'];
        $deacons = [];
        foreach ($nomes as $i => $nome) {
            $m = (new Member())
                ->setFullName($nome)
                ->setChurchRole($i < 5 ? 'diacono' : 'membro')
                ->setStatus(Member::STATUS_ATIVO)
                ->setMinistry($i < 5 ? $minDiaconia : $minLouvor)
                ->setBirthDate(new \DateTimeImmutable(sprintf('19%02d-%02d-15', 80 + $i, ($i % 12) + 1)))
                ->setPhone('(31) 9'.rand(1000,9999).'-'.rand(1000,9999))
                ->setChurch($church);
            $em->persist($m);

            if ($i < 5) {
                $d = (new Deacon())->setMember($m)->setActive(true)->setChurch($church);
                $em->persist($d);
                $deacons[] = $d;
            }
        }

        // ---- Escalas + designações ----
        $tipos = ['culto','santa_ceia','recepcao','estacionamento','limpeza'];
        foreach ($tipos as $k => $tipo) {
            $s = (new Schedule())
                ->setType($tipo)
                ->setTitle('Escala de '.Schedule::TYPES[$tipo].' — Domingo')
                ->setScheduledAt(new \DateTimeImmutable('+'.($k + 1).' days 19:00'))
                ->setLocation('Templo Sede')
                ->setChurch($church);
            $em->persist($s);

            foreach (array_slice($deacons, 0, 3) as $j => $d) {
                $a = (new ScheduleAssignment())
                    ->setSchedule($s)->setDeacon($d)
                    ->setPosition('Posto '.($j + 1))
                    ->setPresence(ScheduleAssignment::PRESENCE_ESCALADO)
                    ->setChurch($church);
                $em->persist($a);
            }
        }

        // ---- Lançamentos financeiros ----
        for ($i = 0; $i < 20; $i++) {
            $entrada = $i % 3 !== 0;
            $t = (new Transaction())
                ->setDirection($entrada ? 'entrada' : 'saida')
                ->setKind($entrada ? ($i % 2 ? 'dizimo' : 'oferta') : 'despesa')
                ->setAmount((string) rand(50, 2000).'.00')
                ->setOccurredAt(new \DateTimeImmutable('-'.rand(0, 300).' days'))
                ->setDescription($entrada ? 'Contribuição culto' : 'Despesa operacional')
                ->setChurch($church);
            $em->persist($t);
        }

        $em->flush();
    }
}
