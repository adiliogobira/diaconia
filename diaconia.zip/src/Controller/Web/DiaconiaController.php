<?php

namespace App\Controller\Web;

use App\Entity\Deacon;
use App\Entity\Schedule;
use App\Entity\ScheduleAssignment;
use App\Form\ScheduleType;
use App\Repository\DeaconRepository;
use App\Repository\ScheduleAssignmentRepository;
use App\Repository\ScheduleRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

/**
 * MÓDULO 3 — Diaconia. Escalas (culto, Santa Ceia, recepção, estacionamento,
 * limpeza), designação de diáconos e controle de presença.
 */
#[Route('/diaconia')]
#[IsGranted('MODULE_DIACONIA')]
class DiaconiaController extends AbstractController
{
    #[Route('', name: 'diaconia_index', methods: ['GET'])]
    public function index(Request $request, ScheduleRepository $repo, DeaconRepository $deacons): Response
    {
        $type = $request->query->get('type');

        return $this->render('diaconia/index.html.twig', [
            'schedules' => $repo->upcoming($type),
            'type' => $type,
            'types' => Schedule::TYPES,
            'deaconCount' => count($deacons->findBy(['active' => true])),
        ]);
    }

    #[Route('/escala/nova', name: 'diaconia_new', methods: ['GET', 'POST'])]
    public function new(Request $request, ScheduleRepository $repo): Response
    {
        $schedule = new Schedule();
        $form = $this->createForm(ScheduleType::class, $schedule);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $repo->save($schedule);
            $this->addFlash('success', 'Escala criada. Agora designe os diáconos.');

            return $this->redirectToRoute('diaconia_show', ['id' => $schedule->getId()]);
        }

        return $this->render('diaconia/form.html.twig', ['form' => $form]);
    }

    #[Route('/escala/{id}', name: 'diaconia_show', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function show(Schedule $schedule, DeaconRepository $deacons): Response
    {
        $assigned = array_map(fn(ScheduleAssignment $a) => $a->getDeacon()->getId(), $schedule->getAssignments()->toArray());
        $available = array_filter(
            $deacons->findBy(['active' => true]),
            fn(Deacon $d) => !in_array($d->getId(), $assigned, true)
        );

        return $this->render('diaconia/show.html.twig', [
            'schedule' => $schedule,
            'availableDeacons' => $available,
        ]);
    }

    /** Designa um diácono à escala. */
    #[Route('/escala/{id}/designar', name: 'diaconia_assign', methods: ['POST'], requirements: ['id' => '\d+'])]
    public function assign(Request $request, Schedule $schedule, DeaconRepository $deacons, EntityManagerInterface $em): Response
    {
        if (!$this->isCsrfTokenValid('assign'.$schedule->getId(), $request->request->get('_token'))) {
            return $this->redirectToRoute('diaconia_show', ['id' => $schedule->getId()]);
        }

        $deacon = $deacons->find((int) $request->request->get('deacon'));
        if ($deacon) {
            $a = new ScheduleAssignment();
            $a->setSchedule($schedule)->setDeacon($deacon)
              ->setPosition($request->request->get('position'));
            $schedule->addAssignment($a);
            $em->persist($a);
            $em->flush();
            $this->addFlash('success', 'Diácono escalado.');
        }

        return $this->redirectToRoute('diaconia_show', ['id' => $schedule->getId()]);
    }

    /** Marca presença/ausência de um escalado (controle de presença). */
    #[Route('/presenca/{id}/{status}', name: 'diaconia_presence', methods: ['POST'], requirements: ['id' => '\d+'])]
    public function presence(ScheduleAssignment $assignment, string $status, ScheduleAssignmentRepository $repo): Response
    {
        $valid = [
            ScheduleAssignment::PRESENCE_CONFIRMADO,
            ScheduleAssignment::PRESENCE_PRESENTE,
            ScheduleAssignment::PRESENCE_AUSENTE,
        ];
        if (in_array($status, $valid, true)) {
            $assignment->setPresence($status);
            $repo->getEntityManager()->flush();
            $this->addFlash('success', 'Presença atualizada.');
        }

        return $this->redirectToRoute('diaconia_show', ['id' => $assignment->getSchedule()->getId()]);
    }

    /** Histórico de serviços prestados por diácono. */
    #[Route('/diacono/{id}/historico', name: 'diaconia_history', methods: ['GET'], requirements: ['id' => '\d+'])]
    public function history(Deacon $deacon): Response
    {
        return $this->render('diaconia/history.html.twig', ['deacon' => $deacon]);
    }
}
